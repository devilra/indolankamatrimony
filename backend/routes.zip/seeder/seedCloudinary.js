// seeder/seedCloudinary.js

const cloudinary = require("cloudinary").v2;
const path = require("path");

// ⚠️ .env லோடிங்: உங்கள் .env ஃபைல் 'backend' root-ல் இருந்தால் இது அவசியம்.
require("dotenv").config({ path: path.resolve(__dirname, "..", ".env") });

// Cloudinary configuration
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Credentials சரிபார்க்க
console.log(
  `Cloud Name Check: ${
    process.env.CLOUDINARY_CLOUD_NAME ? "Loaded" : "NOT Loaded"
  }`
);

// ✅ Local File Names (ஸ்லாஷ் நீக்கப்பட்டது)
const ProfileImage = [
  "o1.webp",
  "o2.webp",
  "o3.webp",
  "o4.webp",
  "o5.webp",
  "o6.webp",
  "o7.webp",
  "o8.webp",
  "o9.webp",
  "o10.webp",
  "o11.webp",
  "o12.webp",
  "o13.webp",
  "o14.webp",
  "o15.webp",
  "o16.webp",
  "o17.webp",
  "o18.webp",
  "o19.webp",
  "o20.webp",
  "o21.webp",
  "o22.webp",
  "o23.webp",
  "o24.webp",
  "o25.webp",
  "o26.webp",
  "o27.webp",
  "o28.webp",
  "o29.webp",
  "o30.webp",
  // ... மீதி படப் பெயர்கள்
  "o31.webp",
  "o32.webp",
  "o33.webp",
  "o34.webp",
  "o35.webp",
  "o36.webp",
  "o37.webp",
  "o38.webp",
  "o39.webp",
  "o40.webp",
  "o41.webp",
  "o42.webp",
  "o43.webp",
  "o44.webp",
  "o45.webp",
  "o46.webp",
  "o47.webp",
  "o48.webp",
  "o49.webp",
  "o50.webp",
  "o52.webp",
  "o53.webp",
  "o54.webp",
  "o55.webp",
  "o56.webp",
  "o57.webp",
  "o58.webp",
  "o59.webp",
  "o60.webp",
  "o61.webp",
  "o62.webp",
  "o63.webp",
  "o64.webp",
  "o65.webp",
];

// ⚠️ உங்கள் படங்கள் இருக்கும் ஃபோல்டரின் பெயர் (seedCloudinary.js இருக்கும் இடத்தில் இருக்க வேண்டும்)
const LOCAL_IMAGE_FOLDER = "seed_images";

async function seedCloudinary() {
  console.log("☁️ Cloudinary Seed Started");

  const uploadPromises = ProfileImage.map(async (imagePath) => {
    // படப் பெயரில் ஸ்லாஷ் இருந்தாலும், அதை இங்கே நீக்குகிறோம் (Safety check)
    const cleanedImagePath = imagePath.startsWith("/")
      ? imagePath.substring(1)
      : imagePath;

    const fullLocalPath = path.join(
      __dirname,
      LOCAL_IMAGE_FOLDER,
      cleanedImagePath
    ); // இப்போதும் பிழை வந்தால், இந்த log-ஐ uncomment செய்து சரியான பாதையைச் சரிபார்க்கவும்: // console.log(`Attempting to upload from: ${fullLocalPath}`);

    try {
      const result = await cloudinary.uploader.upload(fullLocalPath, {
        folder: "IndolankaMatrimonyProfiles",
        public_id: path.parse(cleanedImagePath).name,
        overwrite: true,
      });
      console.log(
        `✅ Upload Completed: ${cleanedImagePath} -> ${result.secure_url} `
      );

      return {
        url: result.secure_url,
        public_id: result.public_id,
      };
    } catch (error) {
      // ✅ முக்கிய மாற்றம்: error object-ஐ முழுமையாக log செய்கிறோம்
      console.error(`❌ Upload Error for ${cleanedImagePath}:`);
      // JSON.stringify-ஐப் பயன்படுத்தி முழு பிழை ஆப்ஜெக்ட்டையும் அச்சிடவும்
      console.error(JSON.stringify(error, null, 2));

      return null;
    }
  });

  const uploadedImages = await Promise.all(uploadPromises);
  const successImages = uploadedImages.filter((img) => img !== null);

  console.log(
    `\n🎉 மொத்தமாக ${successImages.length} படங்கள் Cloudinary-ல் அப்லோட் செய்யப்பட்டன.`
  );

  return successImages;
}

seedCloudinary()
  .then((data) => {
    console.log("Seed செயல்பாடு முடிந்தது. 🚀");
  })
  .catch((err) => {
    console.error("மொத்த சீடிங்கிலும் ஒரு பெரிய பிழை ஏற்பட்டது:", err);
    process.exit(1);
  });
