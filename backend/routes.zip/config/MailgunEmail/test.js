// --- Mailgun Service File ---
// Idhu dhaan unga server-kku Mailgun API-oda pesura file.

// Step 1: Mailgun library-a import pannunga (npm install mailgun.js)
const formData = require("form-data");
const Mailgun = require("mailgun.js");
const mailgun = new Mailgun(formData);

// Step 2: Client-a initialize pannunga (API key & Domain-a .env-la irundhu edukkum)
const mg = mailgun.client({
  username: "api",
  key: process.env.MAILGUN_API_KEY, // Unga Mailgun API Key
  // Idhu dhaan unga Mailgun sandBox/Verified domain
  // Example: mg.yoursite.com
});

const DOMAIN = process.env.MAILGUN_DOMAIN;
const SENDER_EMAIL = process.env.SENDER_EMAIL || "no-reply@yourdomain.com"; // Email anuppa use panra address

/**
 * Mailgun-a use panni email anuppa.
 * Idhu Promise-a return pannum, aana caller-la idhai await panna koodadhu.
 * * @param {string} to - Yaaruku anuppanum (email address)
 * @param {string} subject - Email subject
 * @param {string} htmlContent - Email body (HTML format)
 * @returns {Promise<any>} Mailgun response promise
 */
exports.sendMailgunEmail = (to, subject, htmlContent) => {
  // Mailgun-oda data structure
  const messageData = {
    from: `Matrimony App <${SENDER_EMAIL}>`,
    to: to,
    subject: subject,
    html: htmlContent,
  };

  if (!DOMAIN || !process.env.MAILGUN_API_KEY) {
    console.error(
      "WARNING: Mailgun environment variables are missing. Email not sent."
    );
    // Error irundhaalum, oru resolved promise-a return pannalam,
    // so that the main flow (controller) block aagadha.
    return Promise.resolve({
      status: "Simulated success due to missing API keys",
    });
  }

  // 🔥 Idhu dhaan API call. Idhu fast-a irukkum and main thread-a block pannaadhu.
  return mg.messages.create(DOMAIN, messageData);
};
